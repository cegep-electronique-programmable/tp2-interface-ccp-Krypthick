/*
 * Programme fait par : Jeff Truong
 * Date : 18 Fev 2025
 * Description : un programme qui mesure le flux magnetique et sa polarite.
 * 
*/


#include "mcc_generated_files/mcc.h"
#include "ecran.h"

void Capture_CallBack(uint16_t capturedVal);
/*
                         Main application
*/
// Variables globales pour stocker la dur�e du signal HIGH et LOW
uint16_t High;
uint16_t Low;
bool Rising = 1;
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();
    
    // D�finition de la fonction de rappel pour la capture du signal
    CCP2_SetCallBack(Capture_CallBack);
    
    // Initialisation de l'affichage LCD
    videEcran();
    curseurPosition(0x00);
    printf("Temps High: ");
    curseurPosition(0x40);
    printf("Periode   : ");
    curseurPosition(0x14);
    printf("FluxMagnet: ");
    
   
    float sensibilite = 2.0; // Sensibilit� du capteur %D/mT pour DRV5057A1/Z1 � 5V
    
    while (1)
    {
        // Calcul du rapport cyclique (duty cycle) en pourcentage
        float dutyCycle = (float)High / (High + Low) * 100.0;
        float fluxMagnetique = (dutyCycle - 50) / sensibilite; // B = (D - 50) / S
        
        
        curseurPosition(0x0C);
        printf("%d us", High/5); // Temps haut en microsecondes
        curseurPosition(0x4C);
        printf("%d us", (High + Low)/5); // P�riode totale en microsecondes
        curseurPosition(0x20);
        
        // Affichage de la densit� du flux magn�tique et de sa polarit�
        if (fluxMagnetique >= 0)
            printf("+%.2f mT", fluxMagnetique); // Champ Nord
        else
            printf("-%.2f mT", fluxMagnetique); // Champ Sud
    }
}

// Fonction de capture d'interruption pour mesurer les dur�es HIGH et LOW du signal PWM
void Capture_CallBack(uint16_t capturedVal)
{
    static uint16_t oldVal;
    if(Rising == 1)
    {
        High = (capturedVal-oldVal); // Calcul de la dur�e HIGH
        oldVal = capturedVal;
        CCP2CON = 0x04; //Falling edge
        Rising = 0;
    }
    else
    {
        Low = (capturedVal - oldVal); // Calcul de la dur�e LOW
        oldVal = capturedVal;
        CCP2CON = 0x05; // Rising edge
        Rising = 1;
    }
}
/**
 End of File
*/